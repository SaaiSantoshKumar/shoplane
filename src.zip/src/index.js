import './index.css';
import React from 'react';
import ReactDOM from 'react-dom/client';
import Home from './pages/Home/Home';
import Men from './pages/Home/Men';
import Women from './pages/Home/Women';
import Jewel from './pages/Home/Jewel';
import Login from './component/Login/LoginHome';
import Signup from './component/Signup/LoginSignup';
import Cart from './component/Cart/CartHome';
import Electronics from './pages/Home/Electronics';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
import reportWebVitals from './reportWebVitals';
import {BrowserRouter,Routes,Route} from 'react-router-dom';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter> 
  <React.StrictMode>
     
     <Routes>
      <Route path='/' element={<Home/>}></Route>
      <Route path='/Men' element={<Men/>}></Route>
      <Route path='/Women' element={<Women/>}></Route>
      <Route path='/Jewel' element={<Jewel/>}></Route>
      <Route path='/Electronics' element={<Electronics/>}></Route>
      <Route path='/Login' element={<Login/>}></Route>
      <Route path='/Signup' element={<Signup/>}></Route>
      <Route path='/Cart' element={<Cart/> }></Route>
  </Routes>  
     </React.StrictMode>
  </BrowserRouter>
   
    
  
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

