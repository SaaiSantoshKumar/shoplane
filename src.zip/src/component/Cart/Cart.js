import React from 'react';
import "./Cart.css";
function Cart(){
    return(
        <div className="container">
        <div className="item1">
    
        </div>
        <div className="item2" >
        <div className="card" >    
         <div className="card-body">
        <h5 className="card-title">Order Summary</h5>
        <p className="card-text">Card subtitle</p><p class="card-text">500</p>
        <p className="card-text">Sub Total</p><p class="card-text">500</p>
        <p className="card-text">Shipping Estimate</p><p class="card-text">500</p>
        <p className="card-text">tax-estimate</p><p class="card-text">500</p>
        <p className="card-text">Order Total</p><p class="card-text">500</p>
        </div>
    </div>
    </div>
</div>        
    );
}
  
export default Cart;   