import Header from "../Header/Header";
import Menu from "../Menu/Menu";
import Cart from "./Cart";
import React from "react";
import { useState } from "react";
import { useEffect } from "react";

import "./CartHome.css";
function CartHome(props)
{
    
  

return (
    <div className="homeContainer">
        
        <div className="topContainer">
            <Header/>
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="menuContainer">
            <Menu />
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="pageContainer5 align-items-center">  
        
            <Cart />
        
        </div>
</div>
    
)

}

export default CartHome;