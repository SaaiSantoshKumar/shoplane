import React from 'react';
import logindetails from './logindetails.json';
import "./Login.css";



function Login({updateState}){
    
    //const {updateState} = undefined || {};
       //const{email,password}=formData;
    
    function handleSubmit(e)
    {
      e.preventDefault();
        if(e.target[0].value==='')
        {
          alert("Enter User Name ");
          
        }else if (e.target[1].value==='')
        {
          
          alert("Enter Password ");
        }
        else{
        if(e.target[0].value===logindetails.email)
        {
            if(e.target[1].value===logindetails.password)
            {
                console.log("Email & password Matching..... ");
                //updateState(true);
            }else{
                console.log("Password Not Matching...... ");
            }

        }else
        { 
            console.log("email Not Matching...... ");
        }
                
      }
    }


  return (
    
  <div className="card align-items-center">
    <div className="row g-0 d-flex">
      
      
        <div className="card-body py-5 px-md-5">

        <form  onSubmit={handleSubmit}>
        <h1 className="text-center text-secondary">Login</h1>

            <div className="form-outline mb-4">
              <input type="email" id="email" className="Input-text" placeholder="Email Address"></input>
              
          </div>

            <div className="form-outline mb-4">
              <input type="password" id="password" className="Input-text" placeholder="Password"></input>
            </div>

          
            
              <div className="col"> Don't have an account? Sign up
             &nbsp;<a href="/Signup">here</a>
              </div>
            
            <button type="submit" className="btn1"><h5>Login</h5></button>

          </form>

        </div>
      </div>
    
  </div>

      
    );
}
  
export default Login;   