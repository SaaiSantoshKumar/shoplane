import Header from "../Header/Header";
import Menu from "../Menu/Menu";
import Login from "./Login"
import { useState } from "react";
import { useEffect } from "react";
import "./LoginHome.css";
function LoginHome(props)
{
    

return (
    <div className="homeContainer">
        
        <div className="topContainer">
            <Header/>
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="menuContainer">
            <Menu />
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="pageContainer1 align-items-center">  
        
            <Login />
        </div>
</div>
    
)

}

export default LoginHome;