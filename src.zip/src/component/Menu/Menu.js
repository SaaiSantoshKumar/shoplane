import "./Menu.css";
import React from "react";
import {Link} from 'react-router-dom';
import Home from "../../pages/Home/Home";
import Men from "../../pages/Home/Men";
import Women from "../../pages/Home/Women";
import Jewel from "../../pages/Home/Jewel";
import Electronics from "../../pages/Home/Electronics";
//import {useRef, useEffect,useState} from 'react';
//const { useState } = React;
function Menu()
{
  /*const [item,setitem]=useState();
  const [mens,setmens]=useState();
  const [electric,setelectric]=useState();
  useEffect(()=>{
    fetch("mens.json").then(res2=>res2.json()).then(res2=>{
        //console.log(res1);
        setmens(res2);
        console.log(...mens);
    })
},[]);
useEffect(()=>{
  fetch("Item.json").then(res1=>res1.json()).then(res1=>{
      //console.log(res1);
      setitem(res1);
      console.log(...Item);
  })
},[]);

useEffect(()=>{
  fetch("elecritcal.json").then(res3=>res3.json()).then(res3=>{
      //console.log(res1);
      setelectric(res3);
      console.log(...electric);
  })
},[]);*/
return (
    <div className="menuContainer">
  
<ul className="nav">
  <li className="nav-item spacearound">

    <a className="nav-link active text-secondary fw-semibold"  href="/" > All</a>
  </li>
  <li className="nav-item spacearound">
  <a className="nav-link active text-secondary fw-semibold"  href="/Electronics" > Electronics</a>
    
  </li>
  <li className="nav-item spacearound">
  <a className="nav-link active text-secondary fw-semibold"  href="/Jewel" > Jewelery</a>
    
  </li>
  <li className="nav-item spacearound">
  <a className="nav-link active text-secondary fw-semibold"  href="/Men" > Men's Colothing</a>
    
  </li>
  <li className="nav-item spacearound">
  <a className="nav-link active text-secondary fw-semibold"  href="/Women" > Women's Colothing</a>
    
  </li>
</ul>
    </div>
)

}

export default Menu;