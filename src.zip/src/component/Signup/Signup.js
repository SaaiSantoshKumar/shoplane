import React from 'react';
import "./Signup.css";
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
 
const SignupSchema = Yup.object().shape({
  firstname: Yup.string()
  .min(3,'Too Short!')
  .max(50,'Too Long!')
  .required('Required'),
  lastname: Yup.string()
  .min(3,'Too Short!')
  .max(50,'Too Long!')
  .required('Required'),
  email: Yup.string()
  .min(3,'Too Short!')
  .email('Invalid email')
  .required('Required'),
  password: Yup.string()
  .min(5,'Minium 5 char required')
  .required('Required'),
  confirmpassword: Yup.string()
  .min(5,'Minium 5 char required')
  .required('Required'),
});

function Signup(){
  return (
    <div className="card align-items-center">   
    <h2 className="text-center text-secondary">Sign up</h2>
    <Formik        
        initialValues={{
        firstname: '',
        lastname: '',
         email: '',
         password:'',
         confirmpassword:'',
       }}
       validationSchema={SignupSchema}
       onSubmit={values => {
         console.log(values);
       }}
     >

    {({ errors, touched }) => (
        <Form>
        <div className="form-row">
          <div className="form-outline mb-4">
              <Field type="text" className="Input-text" name="firstname" placeholder="First name"   />
              {errors.firstname && touched.firstname ? (<div className="error">{errors.firstname}</div>) : null}
            </div>
        <div className="form-outline mb-4">
          <Field type="text" className="Input-text " name="lastname" placeholder="Last name"  />
          {errors.lastname && touched.firstname ? (<div className="error">{errors.lastname}</div>) : null}
        </div>
        <div className="form-outline mb-4" >
          <Field type="text" className="Input-text" name="email" placeholder="Email Adress"  />
          {errors.email && touched.email ? (<div className="error">{errors.email}</div>) : null}
        </div>
        <div className="form-outline mb-4">
          <Field type="password" className="Input-text" name="password" placeholder="Password"  />
          {errors.password && touched.password ? (<div className="error">{errors.password}</div>) : null}
        </div>
        <div className="form-outline mb-4">
          <Field type="password" className="Input-text" name="confirmpassword" placeholder="Confirm Password"  />
          {errors.confirmpassword && touched.confirmpassword ? (<div className="error">{errors.confirmpassword}</div>) : null}
        </div>
  </div>
  
            <div className="col"> Alreact have an account ?
             &nbsp;<a href="/Login">login</a>
              </div>
            
            <button type="submit" className="btn1"><h5>Sign up</h5></button>
            
      </Form>  
            )}


    </Formik>
</div>   
      
    );
}
  
export default Signup;   