import Header from "../Header/Header";
import Menu from "../Menu/Menu";
import Signup from "./Signup"
import { useState } from "react";
import { useEffect } from "react";
import "./LoginSignup.css";
function LoginHome(props)
{
    

return (
    <div className="homeContainer">
        
        <div className="topContainer">
            <Header/>
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="menuContainer">
            <Menu />
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="pageContainer2 align-items-center">  
        
            <Signup />
        </div>
</div>
    
)

}

export default LoginHome;