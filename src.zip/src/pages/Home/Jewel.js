import Header from "../../component/Header/Header";
import Menu from "../../component/Menu/Menu";
import Item from "../Items/Item";
import { useState } from "react";
import { useEffect } from "react";
import "./Home.css";
function Home(props)
{
    
    
    const [jewel,setjewel]=useState([]);
    useEffect(()=>{
        fetch("jewel.json").then(res3=>res3.json()).then(res3=>{
            console.log(res3);
            setjewel(res3);
            console.log(...jewel);
        })
    },[]);
return (
    <div className="homeContainer">
        
        <div className="topContainer">
            <Header/>
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="menuContainer">
            <Menu />
        </div>
        <div className="line-4">
            <hr/>
        </div>
        <div className="pageContainer">  
        <h2> {props.number} </h2>
        <div className="row row-cols-1 row-cols-md-4">
        {
            jewel.map(jewel=>
                <div className="col-lg-3 mb-2 d-flex align-items-stretch">
                        <Item  data={jewel}/>   
                </div>        
                    
               )

        }
        </div>
        
    </div>
    </div>
    
)

}

export default Home;